# SRS: FitDesk Enquiry Assistant (CLI MVP)

Version 0.1 · RAHN Jan 2027 assessment · Status: draft

## 1. Business objective
- Cut the time staff spend answering package-price and Saturday-availability enquiries.
- Guarantee every reply uses only approved data (no invented prices or availability) and that nothing is recorded as sent without staff approval.

## 2. Stakeholders
- **Studio owner:** owns the price list and availability file; accountable for what customers are told.
- **Staff member:** runs the tool, reads each draft, approves or rejects it.
- **Customer:** receives the reply; harmed by wrong prices or false availability.
- **RAHN (developer):** builds and maintains the tool.

## 3. Scope
**In scope**
- Customer message typed at the command line.
- Gemini call that returns structured JSON (intent, details, requires_human_approval), validated with Pydantic.
- Lookup in a local JSON data file; reply drafted from that data only.
- Staff approval prompt and a local status log.

**Out of scope**
- WhatsApp, bookings, calendar, payments, discounts or negotiation, training advice.
- Actually delivering the message to the customer (staff send it themselves; see A3).
- Multiple users, customer profiles, any database.

## 4. Functional requirements
- **FR-01** The system accepts one non-empty customer message typed at the command line.
- **FR-02** The system sends the message to Gemini and receives JSON containing at least `intent`, `details` and `requires_human_approval`. The JSON is validated against a Pydantic model; anything that fails validation is rejected.
- **FR-03** The system looks up prices and Saturday slot status only in the local data file.
- **FR-04** The system drafts the reply from looked-up facts only. For any part it cannot answer from the data, the reply includes exactly: `I'll check with the owner and come back to you.` If nothing can be answered, the reply is exactly that sentence.
- **FR-05** The system prints the draft and asks `Send? (y/n)`. Only `y` leads to a `sent` status.
- **FR-06** Every enquiry outcome (sent, rejected, failed) is appended to `status_log.json` with timestamp, message, intent, draft, status and reason.
- **FR-07** The system never records `sent` after an AI failure, a timeout, invalid AI output, or a `n` answer.

## 5. Non-functional requirements
- **NFR-01 Security:** the API key lives only in `.env` (git-ignored); `.env.example` is committed; tests need no key.
- **NFR-02 Reliability:** the system fails closed. AI errors, timeouts (15 s) and bad output produce a clear message and a failure record, never a crash or a draft.
- **NFR-03 Cost:** free tools only; one Gemini call per enquiry; tests make zero API calls (Gemini is mocked).

## 6. Data inputs and outputs
- **Inputs:** customer message (text); `data/fitdesk_data.json` (3 package prices, 3 Saturday slot statuses); `GEMINI_API_KEY` env var.
- **Gemini output:** `{intent, details{packages, slot_times, asks_saturday_availability, unsupported_topics}, requires_human_approval}`. Gemini only classifies and extracts; it never writes prices or availability.
- **Outputs:** draft text on screen; one record per enquiry in `status_log.json`.

## 7. Approval and failure rules
- **Staff say `n`:** record `rejected`; nothing is sent.
- **Staff say `y`:** record `sent`, including when the draft is an escalation message (`escalated: true`).
- **Facts missing** (unknown package, unknown time, unsupported topic, booking request, other intent): the draft carries the exact escalation phrase and still needs approval.
- **AI fails or times out:** record `failed_ai_service`; no draft is shown.
- **AI JSON invalid or off-schema:** record `failed_invalid_output`; no draft is shown.
- **Data file unreadable:** record `failed_data_file`; no draft is shown.
- The `requires_human_approval` value from the AI is stored but never used to skip approval. Approval is always required.

## 8. Acceptance criteria
- **AC-01** Given "How much is the 12-session pack and do you have Saturday slots?", the draft contains R1,680 and the status of each Saturday slot exactly as in the data file.
- **AC-02** Given a question about a package not in the data file, the draft contains the exact escalation phrase and no price for that package.
- **AC-03** Given invalid JSON from the AI, no draft is shown and the log entry is `failed_invalid_output`.
- **AC-04** Given the AI service raising an error, no draft is shown and the log entry is `failed_ai_service`.
- **AC-05** Given the answer `n`, the log entry is `rejected` and no `sent` entry exists for that message.
- **AC-06** Given the answer `y` on a normal draft, the log entry is `sent`.
- **AC-07** All automated tests pass with no API key set.

## 9. Ambiguities and assumptions
- **A1. Which Saturday?** The data has times but no date. *Ask:* is the file always for the coming Saturday? *Assumption:* yes; replies say "Saturday 09:00" and never state a date.
- **A2. Partial answers.** A message may mix answerable and unanswerable questions. *Ask:* should the whole reply be escalated? *Assumption:* answer what is in the data and add the escalation sentence for the rest.
- **A3. What "sent" means.** The CLI has no channel. *Ask:* should it ever message customers directly? *Assumption:* `sent` means staff approved the text and will paste it into WhatsApp themselves.
- **A4. Full slots.** *Ask:* may the bot offer a waiting list? *Assumption:* no; it only states the slot is Full.
