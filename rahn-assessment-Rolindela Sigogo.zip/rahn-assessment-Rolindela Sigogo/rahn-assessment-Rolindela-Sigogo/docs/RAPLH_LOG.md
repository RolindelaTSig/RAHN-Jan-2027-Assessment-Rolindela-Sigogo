# RAPLH Log

AI tool used: Claude (chat). Each entry is labelled **GENUINE** (it really happened in my work) or **ILLUSTRATIVE** (an example, not a record). Maximum attempts per fix: 2 (then I stop and rethink or ask for help).

## Entry 1: SRS and first build — GENUINE
- **Task / expectation:** write the mini-SRS, then a first working CLI version that never records `sent` unless staff approve.
- **Prompt summary:** gave the AI the assessment PDF and playbook; asked it to write the SRS first, then the initial code.
- **Files changed:** `docs/SRS.md`, `data/fitdesk_data.json`, `fitdesk/` (models, llm, drafting, agent, status_log), `main.py`, `tests/test_agent.py`, `requirements.txt`, `.env.example`, `.gitignore`, `README.md`.
- **Test run and result:** `python -m pytest -q` → 6 passed.
- **Corrected:** one weak assertion in the unknown-package test (it checked for the letter "R" in a way that could never fail) was replaced with a check that the draft contains no digits; re-run: 6 passed.
- **My own corrections after running it:**
  - Changed the Gemini model from Gemini 2.5 Flash-Lite to Gemini 3.5 Flash-Lite for the API call.
  - Corrected the `ask_staff` function in `main.py` because it was giving me errors (I did not save the exact error message, so I cannot quote it).
- **Approval decision:** I read and ran the code myself and approved it after making those corrections.

## Entry 2: pytest could not find the package — GENUINE
- **Task / expectation:** README says the test command is `pytest`; I expected that to work.
- **Prompt summary:** asked the AI to check that the plain `pytest` command in the README really works.
- **Test run and result:** `pytest -q` → `ModuleNotFoundError: No module named 'fitdesk'` (the earlier `python -m pytest` had hidden this, because it adds the current folder to the import path).
- **Files changed:** added `pytest.ini` (`pythonpath = .`, `testpaths = tests`); `tests/test_agent.py` now builds the data path from `__file__` instead of a relative path; added a separate staff-says-`y` test.
- **Re-run result:** `pytest -v` → 7 passed.
- **Approval decision:** I reviewed the changes and approved them.

## Entry 3: first live run failed with `failed_data_file` — GENUINE
- **Task / expectation:** run `python main.py` with my real key and a real enquiry; expected a draft with the price and Saturday slots.
- **What happened:** the program printed `Could not draft a reply (Data file was missing or malformed). Nothing was sent.` and `Status recorded: failed_data_file`. No draft was shown, so the program failed closed as designed, but it was not useful.
- **Prompt summary:** gave the AI the exact output and asked what could cause it.
- **Analysis (to be confirmed by me):** `main.py` used the relative path `data/fitdesk_data.json`, which only works if the program is started from the project folder. The same error status is also produced by a malformed data file or a missing key inside it. The old message did not say which one, so I could not tell from the output.
- **Files changed:** `main.py` (data and log paths now built from `__file__`), `fitdesk/agent.py` (the logged reason now names the actual error, e.g. `FileNotFoundError`), `tests/test_agent.py` (new test for a missing data file).
- **Test run and result:** `pytest` → 8 passed (the new test is RT-08).
- **Re-run of the real program after the fix:** `python main.py` worked and showed a draft.
- **Approval decision:** I reviewed the changes and approved them.

## Reflection questions
**1. How would I stop an AI coding agent from changing unrelated files or exposing my API key?**
I would list the files it may touch for each task and refuse any diff outside that list. I would read every diff before accepting it and check `git status` before each commit. The key lives only in `.env`, which is in `.gitignore`; only `.env.example` is committed. I would also search the repo for the key before pushing.

**2. How would I stop the loop if the agent keeps repeating the same failed fix?**
By setting a limit up front: if the same fix fails twice, I stop. I read the error myself, find the real cause, and then either give the agent a different instruction or ask a mentor. I would not let it retry blindly.
