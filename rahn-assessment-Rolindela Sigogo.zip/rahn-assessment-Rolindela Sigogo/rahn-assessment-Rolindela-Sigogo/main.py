"""FitDesk enquiry assistant (CLI). Run: python main.py"""
from dotenv import load_dotenv

from fitdesk.agent import process_enquiry

DATA_PATH = "data/fitdesk_data.json"
LOG_PATH = "status_log.json"


def ask_staff(draft: str) -> bool:
    print("\n--- DRAFT REPLY ---")
    print(draft)
    print("-------------------")
    while True:
        try:
            answer = input("Send? (y/n) ").strip().lower()
        except EOFError:
            return False
        if answer in ("y", "n"):
            return answer == "y"
        print("Please type y or n.")


def main() -> None:
    load_dotenv()
    message = input("Customer message: ").strip()
    if not message:
        print("No message entered. Nothing recorded.")
        return
    record = process_enquiry(message, ask_staff, DATA_PATH, LOG_PATH)
    status = record["status"]
    if status.startswith("failed"):
        print(f"\nCould not draft a reply ({record['reason']}). Nothing was sent.")
    print(f"Status recorded: {status}")


if __name__ == "__main__":
    main()
