import json

import pytest

from fitdesk import agent
from fitdesk.drafting import ESCALATION_PHRASE
from fitdesk.llm import LLMError

DATA = "data/fitdesk_data.json"


def ai_json(intent="package_pricing", packages=(), slots=(), asks=False, unsupported=()):
    return json.dumps({
        "intent": intent,
        "details": {
            "packages": list(packages), "slot_times": list(slots),
            "asks_saturday_availability": asks, "unsupported_topics": list(unsupported),
        },
        "requires_human_approval": True,
    })


@pytest.fixture
def run(tmp_path, monkeypatch):
    log = tmp_path / "status_log.json"

    def _run(ai_reply, answer, message="hi"):
        shown = []

        def fake_ai(_msg):
            if isinstance(ai_reply, Exception):
                raise ai_reply
            return ai_reply

        monkeypatch.setattr(agent, "call_gemini", fake_ai)
        rec = agent.process_enquiry(message, lambda d: (shown.append(d), answer)[1], DATA, log)
        return rec, shown

    return _run


def test_normal_enquiry_is_drafted_from_data_and_sent_on_yes(run):  # FR-03/04/05/06, AC-01, AC-06
    reply = ai_json("pricing_and_availability", packages=["12"], asks=True)
    rec, shown = run(reply, True)
    assert "12 sessions: R1,680." in shown[0]
    assert "Saturday 10:00: Full." in shown[0]
    assert ESCALATION_PHRASE not in shown[0]
    assert rec["status"] == "sent"


def test_unknown_package_uses_escalation_phrase_and_no_price(run):  # FR-04, AC-02
    rec, shown = run(ai_json(packages=["20"]), True)
    assert shown[0] == ESCALATION_PHRASE
    assert not any(ch.isdigit() for ch in shown[0])  # no invented price
    assert rec["escalated"] is True


def test_staff_no_is_never_sent(run):  # FR-05/07, AC-05
    rec, _ = run(ai_json(packages=["5"]), False)
    assert rec["status"] == "rejected"


def test_invalid_json_fails_closed(run):  # FR-02/07, AC-03
    rec, shown = run("this is not json {", True)
    assert rec["status"] == "failed_invalid_output"
    assert shown == []


def test_off_schema_json_fails_closed(run):  # FR-02/07, AC-03
    rec, shown = run('{"intent": "chitchat"}', True)
    assert rec["status"] == "failed_invalid_output"
    assert shown == []


def test_ai_service_failure_fails_closed(run):  # FR-07, NFR-02, AC-04
    rec, shown = run(LLMError("timeout"), True)
    assert rec["status"] == "failed_ai_service"
    assert shown == []
