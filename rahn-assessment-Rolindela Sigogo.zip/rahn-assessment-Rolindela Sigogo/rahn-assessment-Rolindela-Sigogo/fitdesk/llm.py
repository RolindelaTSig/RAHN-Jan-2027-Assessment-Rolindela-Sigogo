"""The only module that talks to Gemini. Tests mock `call_gemini`."""
import os

from .models import EnquiryAnalysis

TIMEOUT_MS = 15_000
DEFAULT_MODEL = "gemini-2.5-flash"  # override with GEMINI_MODEL in .env

SYSTEM_PROMPT = """You classify enquiries for a small fitness studio.
Return JSON only. Do NOT answer the customer. Do NOT state any price or availability.
- intent: package_pricing, saturday_availability, pricing_and_availability, booking_request or other.
- details.packages: package keys the customer mentions: "single", "5" or "12".
  If they mention any other size (e.g. 20 sessions) include it as written, e.g. "20".
- details.slot_times: Saturday times mentioned, as 24h HH:MM (e.g. "09:00").
- details.asks_saturday_availability: true if they ask about Saturday slots.
- details.unsupported_topics: short labels for anything else they ask
  (e.g. "discount", "sunday availability", "nutrition advice").
- requires_human_approval: always true."""


class LLMError(Exception):
    """Any failure talking to the AI service (no key, network, timeout, empty reply)."""


def call_gemini(message: str) -> str:
    """Return the raw JSON text from Gemini. Raises LLMError on any failure."""
    api_key = os.getenv("GEMINI_API_KEY")
    if not api_key:
        raise LLMError("GEMINI_API_KEY is not set")
    try:
        from google import genai
        from google.genai import types

        client = genai.Client(
            api_key=api_key,
            http_options=types.HttpOptions(timeout=TIMEOUT_MS),
        )
        response = client.models.generate_content(
            model=os.getenv("GEMINI_MODEL", DEFAULT_MODEL),
            contents=message,
            config=types.GenerateContentConfig(
                system_instruction=SYSTEM_PROMPT,
                response_mime_type="application/json",
                response_schema=EnquiryAnalysis,
                temperature=0,
            ),
        )
        text = response.text
    except Exception as exc:  # network, auth, timeout, SDK errors
        raise LLMError(f"AI service failed: {type(exc).__name__}") from exc
    if not text:
        raise LLMError("AI service returned an empty reply")
    return text
