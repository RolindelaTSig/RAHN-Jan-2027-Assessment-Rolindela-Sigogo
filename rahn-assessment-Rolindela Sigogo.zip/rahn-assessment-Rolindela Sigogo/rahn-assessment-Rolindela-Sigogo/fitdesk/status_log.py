"""Local status log (status_log.json): a JSON list of records."""
import json
import os
from datetime import datetime, timezone
from pathlib import Path


def append_record(log_path, record: dict) -> dict:
    path = Path(log_path)
    entries = json.loads(path.read_text(encoding="utf-8")) if path.exists() else []
    full = {"timestamp": datetime.now(timezone.utc).isoformat(timespec="seconds"), **record}
    entries.append(full)
    tmp = path.with_suffix(".tmp")
    tmp.write_text(json.dumps(entries, indent=2, ensure_ascii=False), encoding="utf-8")
    os.replace(tmp, path)  # atomic: never leaves a half-written log
    return full
