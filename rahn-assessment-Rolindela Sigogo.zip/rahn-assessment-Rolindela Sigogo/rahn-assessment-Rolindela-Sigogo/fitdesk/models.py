"""Pydantic models for the structured JSON we require from Gemini.

All fields are required on purpose: a missing field is treated as invalid
output (fail closed), not silently defaulted.
"""
from typing import Literal

from pydantic import BaseModel


class Details(BaseModel):
    # Package keys as used in the data file: "single", "5", "12" (or anything else the customer asked for)
    packages: list[str]
    # Saturday times the customer asked about, HH:MM 24h, e.g. "09:00"
    slot_times: list[str]
    # True if they ask about Saturday availability in general
    asks_saturday_availability: bool
    # Anything we cannot answer from the data: discounts, other days, injuries, etc.
    unsupported_topics: list[str]


class EnquiryAnalysis(BaseModel):
    intent: Literal[
        "package_pricing",
        "saturday_availability",
        "pricing_and_availability",
        "booking_request",
        "other",
    ]
    details: Details
    requires_human_approval: bool
