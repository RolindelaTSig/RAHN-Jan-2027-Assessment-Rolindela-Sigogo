"""Pipeline: message -> Gemini JSON -> validate -> lookup/draft -> approval -> log.

Fail closed: "sent" is only ever recorded on the single path where the AI
output validated AND staff approved.
"""
import json
from pathlib import Path
from typing import Callable

from pydantic import ValidationError

from .drafting import build_draft
from .llm import LLMError, call_gemini
from .models import EnquiryAnalysis
from .status_log import append_record


def process_enquiry(
    message: str,
    approve: Callable[[str], bool],
    data_path: str | Path,
    log_path: str | Path,
) -> dict:
    base = {"customer_message": message, "intent": None, "draft": None, "escalated": None}

    def fail(status: str, reason: str) -> dict:
        return append_record(log_path, {**base, "status": status, "reason": reason})

    try:
        raw = call_gemini(message)
    except LLMError as exc:
        return fail("failed_ai_service", str(exc))

    try:
        analysis = EnquiryAnalysis.model_validate_json(raw)
    except ValidationError:
        return fail("failed_invalid_output", "AI output did not match the expected schema")

    try:
        data = json.loads(Path(data_path).read_text(encoding="utf-8"))
        draft = build_draft(analysis, data)
    except (OSError, ValueError, KeyError):
        return fail("failed_data_file", "Data file missing or malformed")

    base.update(intent=analysis.intent, draft=draft.text, escalated=draft.escalated)
    approved = approve(draft.text) is True
    return append_record(
        log_path,
        {
            **base,
            "status": "sent" if approved else "rejected",
            "reason": "approved by staff" if approved else "staff answered n",
            "ai_requires_human_approval": analysis.requires_human_approval,
        },
    )
