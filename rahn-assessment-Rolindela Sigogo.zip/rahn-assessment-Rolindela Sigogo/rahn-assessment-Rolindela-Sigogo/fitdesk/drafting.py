"""Builds the reply from the data file only. No AI-written facts."""
import re
from dataclasses import dataclass

from .models import EnquiryAnalysis

ESCALATION_PHRASE = "I'll check with the owner and come back to you."


@dataclass
class Draft:
    text: str
    escalated: bool


def _norm_key(value: str) -> str:
    return value.strip().lower()


def _norm_time(value: str) -> str:
    m = re.fullmatch(r"(\d{1,2}):(\d{2})", value.strip())
    return f"{int(m.group(1)):02d}:{m.group(2)}" if m else value.strip()


def build_draft(analysis: EnquiryAnalysis, data: dict) -> Draft:
    packages = data["packages"]
    slots = data["saturday_slots"]
    facts: list[str] = []
    escalate = (
        analysis.intent in ("booking_request", "other")
        or bool(analysis.details.unsupported_topics)
    )

    for raw in dict.fromkeys(_norm_key(p) for p in analysis.details.packages):
        pkg = packages.get(raw)
        if pkg:
            facts.append(f"{pkg['label']}: R{pkg['price_zar']:,}.")
        else:
            escalate = True

    times = list(dict.fromkeys(_norm_time(t) for t in analysis.details.slot_times))
    if not times and analysis.details.asks_saturday_availability:
        times = list(slots)
    for t in times:
        if t in slots:
            facts.append(f"Saturday {t}: {slots[t]}.")
        else:
            escalate = True

    if not facts:
        escalate = True
    if escalate:
        facts.append(ESCALATION_PHRASE)
    return Draft(text="\n".join(facts), escalated=escalate)
